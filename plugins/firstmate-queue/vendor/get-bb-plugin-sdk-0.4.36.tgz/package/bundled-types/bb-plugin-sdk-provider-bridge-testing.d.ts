// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

import { z } from 'zod';

interface JsonObject {
    [key: string]: JsonValue;
}
type JsonValue = string | number | boolean | null | JsonValue[] | JsonObject;

declare const threadEventItemPresentationLabelSchema: z.ZodObject<{
    completed: z.ZodString;
    pending: z.ZodString;
}, z.core.$strip>;
type ThreadEventItemPresentationLabel = z.infer<typeof threadEventItemPresentationLabelSchema>;
declare const threadEventItemPresentationIconSchema: z.ZodObject<{
    glyph: z.ZodString;
}, z.core.$strip>;
type ThreadEventItemPresentationIcon = z.infer<typeof threadEventItemPresentationIconSchema>;
declare const threadEventItemPresentationTintSchema: z.ZodObject<{
    dark: z.ZodString;
    light: z.ZodString;
}, z.core.$strip>;
type ThreadEventItemPresentationTint = z.infer<typeof threadEventItemPresentationTintSchema>;
declare const threadEventItemPresentationSchema: z.ZodObject<{
    detail: z.ZodOptional<z.ZodString>;
    icon: z.ZodObject<{
        glyph: z.ZodString;
    }, z.core.$strip>;
    label: z.ZodObject<{
        completed: z.ZodString;
        pending: z.ZodString;
    }, z.core.$strip>;
    suppress: z.ZodOptional<z.ZodBoolean>;
    tint: z.ZodOptional<z.ZodObject<{
        dark: z.ZodString;
        light: z.ZodString;
    }, z.core.$strip>>;
    title: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
type ThreadEventItemPresentation = z.infer<typeof threadEventItemPresentationSchema>;

declare const threadEventWebSearchItemSchema: z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    queries: z.ZodArray<z.ZodString>;
    resultText: z.ZodNullable<z.ZodString>;
    type: z.ZodLiteral<"webSearch">;
}, z.core.$strip>;
type ThreadEventWebSearchItem = z.infer<typeof threadEventWebSearchItemSchema>;
declare const threadEventWebFetchItemSchema: z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    pattern: z.ZodNullable<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    prompt: z.ZodNullable<z.ZodString>;
    resultText: z.ZodNullable<z.ZodString>;
    type: z.ZodLiteral<"webFetch">;
    url: z.ZodString;
}, z.core.$strip>;
type ThreadEventWebFetchItem = z.infer<typeof threadEventWebFetchItemSchema>;
declare const threadEventFileReadItemSchema: z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    type: z.ZodLiteral<"fileRead">;
}, z.core.$strip>;
type ThreadEventFileReadItem = z.infer<typeof threadEventFileReadItemSchema>;
declare const threadEventSearchItemSchema: z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    mode: z.ZodEnum<{
        content: "content";
        list: "list";
        path: "path";
    }>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    path: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    query: z.ZodString;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    type: z.ZodLiteral<"search">;
}, z.core.$strip>;
type ThreadEventSearchItem = z.infer<typeof threadEventSearchItemSchema>;
declare const threadEventDelegationItemSchema: z.ZodObject<{
    background: z.ZodBoolean;
    childRef: z.ZodString;
    id: z.ZodString;
    label: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    summary: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"delegation">;
}, z.core.$strip>;
type ThreadEventDelegationItem = z.infer<typeof threadEventDelegationItemSchema>;
declare const threadEventPlanStepsItemSchema: z.ZodObject<{
    explanation: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    steps: z.ZodArray<z.ZodObject<{
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            completed: "completed";
            failed: "failed";
            pending: "pending";
        }>>;
        step: z.ZodString;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"planSteps">;
}, z.core.$strip>;
type ThreadEventPlanStepsItem = z.infer<typeof threadEventPlanStepsItemSchema>;
declare const threadEventExtensionItemSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    presentation: z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    type: z.ZodLiteral<"extension">;
}, z.core.$strip>;
type ThreadEventExtensionItem = z.infer<typeof threadEventExtensionItemSchema>;
declare const threadEventBackgroundTaskItemSchema: z.ZodObject<{
    description: z.ZodString;
    error: z.ZodOptional<z.ZodString>;
    familyId: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    outputFile: z.ZodOptional<z.ZodString>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    skipTranscript: z.ZodBoolean;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    summary: z.ZodOptional<z.ZodString>;
    taskStatus: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        killed: "killed";
        paused: "paused";
        pending: "pending";
        running: "running";
        stopped: "stopped";
    }>;
    taskType: z.ZodString;
    type: z.ZodLiteral<"backgroundTask">;
    usage: z.ZodOptional<z.ZodObject<{
        durationMs: z.ZodNumber;
        toolUses: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>>;
    workflow: z.ZodOptional<z.ZodObject<{
        agents: z.ZodArray<z.ZodObject<{
            agentType: z.ZodOptional<z.ZodString>;
            attempt: z.ZodNumber;
            cached: z.ZodBoolean;
            durationMs: z.ZodOptional<z.ZodNumber>;
            error: z.ZodOptional<z.ZodString>;
            index: z.ZodNumber;
            isolation: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            lastProgressAt: z.ZodNumber;
            lastToolName: z.ZodOptional<z.ZodString>;
            lastToolSummary: z.ZodOptional<z.ZodString>;
            model: z.ZodString;
            phaseIndex: z.ZodOptional<z.ZodNumber>;
            phaseTitle: z.ZodOptional<z.ZodString>;
            promptPreview: z.ZodOptional<z.ZodString>;
            queuedAt: z.ZodOptional<z.ZodNumber>;
            resultPreview: z.ZodOptional<z.ZodString>;
            startedAt: z.ZodOptional<z.ZodNumber>;
            state: z.ZodEnum<{
                done: "done";
                failed: "failed";
                queued: "queued";
                running: "running";
                skipped: "skipped";
            }>;
            tokens: z.ZodOptional<z.ZodNumber>;
            toolCalls: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        phases: z.ZodArray<z.ZodObject<{
            index: z.ZodNumber;
            kind: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    workflowName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
type ThreadEventBackgroundTaskItem = z.infer<typeof threadEventBackgroundTaskItemSchema>;
declare const threadEventItemSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    clientRequestId: z.ZodOptional<z.ZodString>;
    content: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"text">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"image">;
        url: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"localImage">;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"localFile">;
    }, z.core.$strip>], "type">>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"userMessage">;
}, z.core.$strict>, z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    text: z.ZodString;
    type: z.ZodLiteral<"agentMessage">;
}, z.core.$strip>, z.ZodObject<{
    aggregatedOutput: z.ZodOptional<z.ZodString>;
    approvalStatus: z.ZodNullable<z.ZodEnum<{
        denied: "denied";
        waiting_for_approval: "waiting_for_approval";
    }>>;
    command: z.ZodString;
    cwd: z.ZodString;
    durationMs: z.ZodOptional<z.ZodNumber>;
    exitCode: z.ZodOptional<z.ZodNumber>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    truncation: z.ZodOptional<z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodObject<{
            originalLength: z.ZodNumber;
            retainedHeadLength: z.ZodNumber;
            retainedTailLength: z.ZodNumber;
            truncatedAt: z.ZodNumber;
        }, z.core.$strip>>;
        result: z.ZodOptional<z.ZodObject<{
            originalLength: z.ZodNumber;
            retainedHeadLength: z.ZodNumber;
            retainedTailLength: z.ZodNumber;
            truncatedAt: z.ZodNumber;
        }, z.core.$strip>>;
        resultText: z.ZodOptional<z.ZodObject<{
            originalLength: z.ZodNumber;
            retainedHeadLength: z.ZodNumber;
            retainedTailLength: z.ZodNumber;
            truncatedAt: z.ZodNumber;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"commandExecution">;
}, z.core.$strip>, z.ZodObject<{
    approvalStatus: z.ZodNullable<z.ZodEnum<{
        denied: "denied";
        waiting_for_approval: "waiting_for_approval";
    }>>;
    changes: z.ZodArray<z.ZodObject<{
        diff: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            add: "add";
            delete: "delete";
            update: "update";
        }>;
        movePath: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
    }, z.core.$strip>>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    type: z.ZodLiteral<"fileChange">;
}, z.core.$strip>, z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    queries: z.ZodArray<z.ZodString>;
    resultText: z.ZodNullable<z.ZodString>;
    type: z.ZodLiteral<"webSearch">;
}, z.core.$strip>, z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    pattern: z.ZodNullable<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    prompt: z.ZodNullable<z.ZodString>;
    resultText: z.ZodNullable<z.ZodString>;
    type: z.ZodLiteral<"webFetch">;
    url: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"imageView">;
}, z.core.$strip>, z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    type: z.ZodLiteral<"fileRead">;
}, z.core.$strip>, z.ZodObject<{
    cmd: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    mode: z.ZodEnum<{
        content: "content";
        list: "list";
        path: "path";
    }>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    path: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    query: z.ZodString;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    type: z.ZodLiteral<"search">;
}, z.core.$strip>, z.ZodObject<{
    arguments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    durationMs: z.ZodOptional<z.ZodNumber>;
    error: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    result: z.ZodOptional<z.ZodUnknown>;
    server: z.ZodOptional<z.ZodString>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    tool: z.ZodString;
    truncation: z.ZodOptional<z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodObject<{
            originalLength: z.ZodNumber;
            retainedHeadLength: z.ZodNumber;
            retainedTailLength: z.ZodNumber;
            truncatedAt: z.ZodNumber;
        }, z.core.$strip>>;
        result: z.ZodOptional<z.ZodObject<{
            originalLength: z.ZodNumber;
            retainedHeadLength: z.ZodNumber;
            retainedTailLength: z.ZodNumber;
            truncatedAt: z.ZodNumber;
        }, z.core.$strip>>;
        resultText: z.ZodOptional<z.ZodObject<{
            originalLength: z.ZodNumber;
            retainedHeadLength: z.ZodNumber;
            retainedTailLength: z.ZodNumber;
            truncatedAt: z.ZodNumber;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"toolCall">;
}, z.core.$strip>, z.ZodObject<{
    content: z.ZodArray<z.ZodString>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    summary: z.ZodArray<z.ZodString>;
    type: z.ZodLiteral<"reasoning">;
}, z.core.$strip>, z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    text: z.ZodString;
    type: z.ZodLiteral<"plan">;
}, z.core.$strip>, z.ZodObject<{
    explanation: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    steps: z.ZodArray<z.ZodObject<{
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            completed: "completed";
            failed: "failed";
            pending: "pending";
        }>>;
        step: z.ZodString;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"planSteps">;
}, z.core.$strip>, z.ZodObject<{
    id: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"contextCompaction">;
}, z.core.$strip>, z.ZodObject<{
    description: z.ZodString;
    error: z.ZodOptional<z.ZodString>;
    familyId: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    outputFile: z.ZodOptional<z.ZodString>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    skipTranscript: z.ZodBoolean;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    summary: z.ZodOptional<z.ZodString>;
    taskStatus: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        killed: "killed";
        paused: "paused";
        pending: "pending";
        running: "running";
        stopped: "stopped";
    }>;
    taskType: z.ZodString;
    type: z.ZodLiteral<"backgroundTask">;
    usage: z.ZodOptional<z.ZodObject<{
        durationMs: z.ZodNumber;
        toolUses: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>>;
    workflow: z.ZodOptional<z.ZodObject<{
        agents: z.ZodArray<z.ZodObject<{
            agentType: z.ZodOptional<z.ZodString>;
            attempt: z.ZodNumber;
            cached: z.ZodBoolean;
            durationMs: z.ZodOptional<z.ZodNumber>;
            error: z.ZodOptional<z.ZodString>;
            index: z.ZodNumber;
            isolation: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            lastProgressAt: z.ZodNumber;
            lastToolName: z.ZodOptional<z.ZodString>;
            lastToolSummary: z.ZodOptional<z.ZodString>;
            model: z.ZodString;
            phaseIndex: z.ZodOptional<z.ZodNumber>;
            phaseTitle: z.ZodOptional<z.ZodString>;
            promptPreview: z.ZodOptional<z.ZodString>;
            queuedAt: z.ZodOptional<z.ZodNumber>;
            resultPreview: z.ZodOptional<z.ZodString>;
            startedAt: z.ZodOptional<z.ZodNumber>;
            state: z.ZodEnum<{
                done: "done";
                failed: "failed";
                queued: "queued";
                running: "running";
                skipped: "skipped";
            }>;
            tokens: z.ZodOptional<z.ZodNumber>;
            toolCalls: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        phases: z.ZodArray<z.ZodObject<{
            index: z.ZodNumber;
            kind: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    workflowName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    background: z.ZodBoolean;
    childRef: z.ZodString;
    id: z.ZodString;
    label: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    summary: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"delegation">;
}, z.core.$strip>, z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    presentation: z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
    type: z.ZodLiteral<"extension">;
}, z.core.$strip>], "type">;
type ThreadEventItem = z.infer<typeof threadEventItemSchema>;
declare const threadEventSchema: z.ZodPipe<z.ZodUnknown, z.ZodUnion<readonly [z.ZodIntersection<z.ZodDiscriminatedUnion<[z.ZodObject<{
    threadId: z.ZodString;
    type: z.ZodLiteral<"thread/started">;
}, z.core.$strip>, z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"thread/identity">;
}, z.core.$strip>, z.ZodObject<{
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"turn/started">;
}, z.core.$strip>, z.ZodObject<{
    error: z.ZodOptional<z.ZodObject<{
        message: z.ZodString;
    }, z.core.$strip>>;
    providerCheckpointId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodNullable<z.ZodString>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
    }>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"turn/completed">;
}, z.core.$strip>, z.ZodObject<{
    clientRequestId: z.ZodString;
    providerThreadId: z.ZodString;
    scope: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"thread">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"turn">;
        turnId: z.ZodString;
    }, z.core.$strip>], "kind">;
    threadId: z.ZodString;
    type: z.ZodLiteral<"turn/input/accepted">;
}, z.core.$strict>, z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    threadName: z.ZodString;
    type: z.ZodLiteral<"thread/name/updated">;
}, z.core.$strip>, z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"thread/compacted">;
}, z.core.$strip>, z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"thread/context/cleared">;
}, z.core.$strip>, z.ZodObject<{
    objective: z.ZodString;
    providerThreadId: z.ZodString;
    status: z.ZodEnum<{
        active: "active";
        budgetLimited: "budgetLimited";
        complete: "complete";
        paused: "paused";
    }>;
    threadId: z.ZodString;
    timeUsedSeconds: z.ZodNumber;
    tokenBudget: z.ZodNullable<z.ZodNumber>;
    tokensUsed: z.ZodNumber;
    type: z.ZodLiteral<"thread/goal/updated">;
}, z.core.$strip>, z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"thread/goal/cleared">;
}, z.core.$strip>, z.ZodObject<{
    item: z.ZodDiscriminatedUnion<[z.ZodObject<{
        clientRequestId: z.ZodOptional<z.ZodString>;
        content: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            text: z.ZodString;
            type: z.ZodLiteral<"text">;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"image">;
            url: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            path: z.ZodString;
            type: z.ZodLiteral<"localImage">;
        }, z.core.$strip>, z.ZodObject<{
            path: z.ZodString;
            type: z.ZodLiteral<"localFile">;
        }, z.core.$strip>], "type">>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"userMessage">;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        text: z.ZodString;
        type: z.ZodLiteral<"agentMessage">;
    }, z.core.$strip>, z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodString>;
        approvalStatus: z.ZodNullable<z.ZodEnum<{
            denied: "denied";
            waiting_for_approval: "waiting_for_approval";
        }>>;
        command: z.ZodString;
        cwd: z.ZodString;
        durationMs: z.ZodOptional<z.ZodNumber>;
        exitCode: z.ZodOptional<z.ZodNumber>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        truncation: z.ZodOptional<z.ZodObject<{
            aggregatedOutput: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            result: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            resultText: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"commandExecution">;
    }, z.core.$strip>, z.ZodObject<{
        approvalStatus: z.ZodNullable<z.ZodEnum<{
            denied: "denied";
            waiting_for_approval: "waiting_for_approval";
        }>>;
        changes: z.ZodArray<z.ZodObject<{
            diff: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                add: "add";
                delete: "delete";
                update: "update";
            }>;
            movePath: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strip>>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"fileChange">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        queries: z.ZodArray<z.ZodString>;
        resultText: z.ZodNullable<z.ZodString>;
        type: z.ZodLiteral<"webSearch">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        pattern: z.ZodNullable<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        prompt: z.ZodNullable<z.ZodString>;
        resultText: z.ZodNullable<z.ZodString>;
        type: z.ZodLiteral<"webFetch">;
        url: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"imageView">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"fileRead">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        mode: z.ZodEnum<{
            content: "content";
            list: "list";
            path: "path";
        }>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        path: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        query: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"search">;
    }, z.core.$strip>, z.ZodObject<{
        arguments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        result: z.ZodOptional<z.ZodUnknown>;
        server: z.ZodOptional<z.ZodString>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        tool: z.ZodString;
        truncation: z.ZodOptional<z.ZodObject<{
            aggregatedOutput: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            result: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            resultText: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"toolCall">;
    }, z.core.$strip>, z.ZodObject<{
        content: z.ZodArray<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        summary: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"reasoning">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        text: z.ZodString;
        type: z.ZodLiteral<"plan">;
    }, z.core.$strip>, z.ZodObject<{
        explanation: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        steps: z.ZodArray<z.ZodObject<{
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                completed: "completed";
                failed: "failed";
                pending: "pending";
            }>>;
            step: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"planSteps">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"contextCompaction">;
    }, z.core.$strip>, z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        id: z.ZodString;
        label: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        presentation: z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"extension">;
    }, z.core.$strip>], "type">;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/started">;
}, z.core.$strip>, z.ZodObject<{
    item: z.ZodDiscriminatedUnion<[z.ZodObject<{
        clientRequestId: z.ZodOptional<z.ZodString>;
        content: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            text: z.ZodString;
            type: z.ZodLiteral<"text">;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"image">;
            url: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            path: z.ZodString;
            type: z.ZodLiteral<"localImage">;
        }, z.core.$strip>, z.ZodObject<{
            path: z.ZodString;
            type: z.ZodLiteral<"localFile">;
        }, z.core.$strip>], "type">>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"userMessage">;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        text: z.ZodString;
        type: z.ZodLiteral<"agentMessage">;
    }, z.core.$strip>, z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodString>;
        approvalStatus: z.ZodNullable<z.ZodEnum<{
            denied: "denied";
            waiting_for_approval: "waiting_for_approval";
        }>>;
        command: z.ZodString;
        cwd: z.ZodString;
        durationMs: z.ZodOptional<z.ZodNumber>;
        exitCode: z.ZodOptional<z.ZodNumber>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        truncation: z.ZodOptional<z.ZodObject<{
            aggregatedOutput: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            result: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            resultText: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"commandExecution">;
    }, z.core.$strip>, z.ZodObject<{
        approvalStatus: z.ZodNullable<z.ZodEnum<{
            denied: "denied";
            waiting_for_approval: "waiting_for_approval";
        }>>;
        changes: z.ZodArray<z.ZodObject<{
            diff: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                add: "add";
                delete: "delete";
                update: "update";
            }>;
            movePath: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strip>>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"fileChange">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        queries: z.ZodArray<z.ZodString>;
        resultText: z.ZodNullable<z.ZodString>;
        type: z.ZodLiteral<"webSearch">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        pattern: z.ZodNullable<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        prompt: z.ZodNullable<z.ZodString>;
        resultText: z.ZodNullable<z.ZodString>;
        type: z.ZodLiteral<"webFetch">;
        url: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"imageView">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"fileRead">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        mode: z.ZodEnum<{
            content: "content";
            list: "list";
            path: "path";
        }>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        path: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        query: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"search">;
    }, z.core.$strip>, z.ZodObject<{
        arguments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        result: z.ZodOptional<z.ZodUnknown>;
        server: z.ZodOptional<z.ZodString>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        tool: z.ZodString;
        truncation: z.ZodOptional<z.ZodObject<{
            aggregatedOutput: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            result: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
            resultText: z.ZodOptional<z.ZodObject<{
                originalLength: z.ZodNumber;
                retainedHeadLength: z.ZodNumber;
                retainedTailLength: z.ZodNumber;
                truncatedAt: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"toolCall">;
    }, z.core.$strip>, z.ZodObject<{
        content: z.ZodArray<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        summary: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"reasoning">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        text: z.ZodString;
        type: z.ZodLiteral<"plan">;
    }, z.core.$strip>, z.ZodObject<{
        explanation: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        steps: z.ZodArray<z.ZodObject<{
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                completed: "completed";
                failed: "failed";
                pending: "pending";
            }>>;
            step: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"planSteps">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"contextCompaction">;
    }, z.core.$strip>, z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        id: z.ZodString;
        label: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        presentation: z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        type: z.ZodLiteral<"extension">;
    }, z.core.$strip>], "type">;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/completed">;
}, z.core.$strip>, z.ZodObject<{
    delta: z.ZodString;
    itemId: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/agentMessage/delta">;
}, z.core.$strip>, z.ZodObject<{
    delta: z.ZodString;
    itemId: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    reset: z.ZodOptional<z.ZodBoolean>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/commandExecution/outputDelta">;
}, z.core.$strip>, z.ZodObject<{
    delta: z.ZodString;
    itemId: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/fileChange/outputDelta">;
}, z.core.$strip>, z.ZodObject<{
    delta: z.ZodString;
    itemId: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/reasoning/summaryTextDelta">;
}, z.core.$strip>, z.ZodObject<{
    delta: z.ZodString;
    itemId: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/reasoning/textDelta">;
}, z.core.$strip>, z.ZodObject<{
    delta: z.ZodString;
    itemId: z.ZodString;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/plan/delta">;
}, z.core.$strip>, z.ZodObject<{
    itemId: z.ZodString;
    message: z.ZodOptional<z.ZodString>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/mcpToolCall/progress">;
}, z.core.$strip>, z.ZodObject<{
    itemId: z.ZodString;
    message: z.ZodOptional<z.ZodString>;
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/toolCall/progress">;
}, z.core.$strip>, z.ZodObject<{
    item: z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/backgroundTask/progress">;
}, z.core.$strip>, z.ZodObject<{
    item: z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/backgroundTask/completed">;
}, z.core.$strip>, z.ZodObject<{
    item: z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        id: z.ZodString;
        label: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/delegation/progress">;
}, z.core.$strip>, z.ZodObject<{
    item: z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        id: z.ZodString;
        label: z.ZodString;
        parentToolCallId: z.ZodOptional<z.ZodString>;
        presentation: z.ZodOptional<z.ZodObject<{
            detail: z.ZodOptional<z.ZodString>;
            icon: z.ZodObject<{
                glyph: z.ZodString;
            }, z.core.$strip>;
            label: z.ZodObject<{
                completed: z.ZodString;
                pending: z.ZodString;
            }, z.core.$strip>;
            suppress: z.ZodOptional<z.ZodBoolean>;
            tint: z.ZodOptional<z.ZodObject<{
                dark: z.ZodString;
                light: z.ZodString;
            }, z.core.$strip>>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"item/delegation/completed">;
}, z.core.$strip>, z.ZodObject<{
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    tokenUsage: z.ZodObject<{
        last: z.ZodObject<{
            cachedInputTokens: z.ZodNumber;
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            reasoningOutputTokens: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>;
        modelContextWindow: z.ZodNullable<z.ZodNumber>;
        total: z.ZodObject<{
            cachedInputTokens: z.ZodNumber;
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            reasoningOutputTokens: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"thread/tokenUsage/updated">;
}, z.core.$strip>, z.ZodObject<{
    contextWindowUsage: z.ZodObject<{
        estimated: z.ZodBoolean;
        modelContextWindow: z.ZodNullable<z.ZodNumber>;
        usedTokens: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"thread/contextWindowUsage/updated">;
}, z.core.$strip>, z.ZodObject<{
    explanation: z.ZodOptional<z.ZodString>;
    plan: z.ZodArray<z.ZodObject<{
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            completed: "completed";
            failed: "failed";
            pending: "pending";
        }>>;
        step: z.ZodString;
    }, z.core.$strip>>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"turn/plan/updated">;
}, z.core.$strip>, z.ZodObject<{
    diff: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"turn/diff/updated">;
}, z.core.$strip>, z.ZodObject<{
    detail: z.ZodOptional<z.ZodString>;
    errorInfo: z.ZodOptional<z.ZodObject<{
        category: z.ZodEnum<{
            "active-turn-not-steerable": "active-turn-not-steerable";
            "bad-request": "bad-request";
            "budget-exceeded": "budget-exceeded";
            "connection-failed": "connection-failed";
            "context-window-exceeded": "context-window-exceeded";
            "max-output-tokens": "max-output-tokens";
            "max-turns": "max-turns";
            "rate-limit": "rate-limit";
            "stream-disconnected": "stream-disconnected";
            "structured-output-retries": "structured-output-retries";
            "thread-rollback-failed": "thread-rollback-failed";
            "too-many-failed-attempts": "too-many-failed-attempts";
            billing: "billing";
            internal: "internal";
            overloaded: "overloaded";
            policy: "policy";
            sandbox: "sandbox";
            unauthorized: "unauthorized";
            unknown: "unknown";
        }>;
        httpStatusCode: z.ZodNullable<z.ZodNumber>;
        providerCode: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    message: z.ZodString;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"provider/error">;
    willRetry: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    providerThreadId: z.ZodString;
    rateLimits: z.ZodObject<{
        kind: z.ZodEnum<{
            "spend-control": "spend-control";
            "subscription-window": "subscription-window";
            credits: "credits";
            unknown: "unknown";
        }>;
        overageReason: z.ZodNullable<z.ZodString>;
        overageStatus: z.ZodNullable<z.ZodEnum<{
            allowed: "allowed";
            rejected: "rejected";
            unavailable: "unavailable";
            warning: "warning";
        }>>;
        providerId: z.ZodString;
        reachedReason: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<{
            allowed: "allowed";
            blocked: "blocked";
            unknown: "unknown";
            warning: "warning";
        }>;
        windows: z.ZodArray<z.ZodObject<{
            label: z.ZodNullable<z.ZodString>;
            providerKey: z.ZodNullable<z.ZodString>;
            resetsAtMs: z.ZodNullable<z.ZodNumber>;
            status: z.ZodEnum<{
                allowed: "allowed";
                blocked: "blocked";
                unknown: "unknown";
                warning: "warning";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"provider/rateLimits/updated">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
    providerThreadId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"thread/extensionState/updated">;
}, z.core.$strip>, z.ZodObject<{
    category: z.ZodEnum<{
        "compaction-skipped": "compaction-skipped";
        config: "config";
        deprecation: "deprecation";
        general: "general";
    }>;
    details: z.ZodOptional<z.ZodString>;
    providerThreadId: z.ZodString;
    summary: z.ZodOptional<z.ZodString>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"provider/warning">;
}, z.core.$strip>, z.ZodObject<{
    fallbackModel: z.ZodString;
    message: z.ZodString;
    originalModel: z.ZodString;
    providerThreadId: z.ZodString;
    reason: z.ZodEnum<{
        provider: "provider";
        refusal: "refusal";
    }>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"provider/modelFallback">;
}, z.core.$strip>, z.ZodObject<{
    parentToolCallId: z.ZodOptional<z.ZodString>;
    providerId: z.ZodString;
    providerThreadId: z.ZodString;
    rawEvent: z.ZodObject<{
        id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        jsonrpc: z.ZodLiteral<"2.0">;
        method: z.ZodString;
        params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
    }, z.core.$strip>;
    rawType: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"provider/unhandled">;
}, z.core.$strip>], "type">, z.ZodObject<{
    scope: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"thread">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"turn">;
        turnId: z.ZodString;
    }, z.core.$strip>], "kind">;
}, z.core.$strip>>, z.ZodIntersection<z.ZodDiscriminatedUnion<[z.ZodObject<{
    direction: z.ZodLiteral<"outbound">;
    initiator: z.ZodEnum<{
        agent: "agent";
        system: "system";
        user: "user";
    }>;
    request: z.ZodObject<{
        method: z.ZodEnum<{
            "thread/start": "thread/start";
            "turn/start": "turn/start";
        }>;
        params: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strip>;
    source: z.ZodEnum<{
        spawn: "spawn";
        tell: "tell";
    }>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"client/thread/start">;
}, z.core.$strip>, z.ZodObject<{
    direction: z.ZodLiteral<"outbound">;
    execution: z.ZodObject<{
        model: z.ZodString;
        permissionMode: z.ZodEnum<{
            "accept-edits": "accept-edits";
            "workspace-write": "workspace-write";
            auto: "auto";
            full: "full";
            readonly: "readonly";
        }>;
        reasoningLevel: z.ZodEnum<{
            high: "high";
            low: "low";
            max: "max";
            medium: "medium";
            none: "none";
            ultra: "ultra";
            ultracode: "ultracode";
            xhigh: "xhigh";
        }>;
        seq: z.ZodOptional<z.ZodNumber>;
        serviceTier: z.ZodEnum<{
            default: "default";
            fast: "fast";
        }>;
        source: z.ZodEnum<{
            "client/thread/start": "client/thread/start";
            "client/turn/requested": "client/turn/requested";
            "client/turn/start": "client/turn/start";
        }>;
    }, z.core.$strip>;
    initiator: z.ZodEnum<{
        agent: "agent";
        system: "system";
        user: "user";
    }>;
    input: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mentions: z.ZodDefault<z.ZodArray<z.ZodObject<{
            end: z.ZodNumber;
            resource: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"thread">;
                label: z.ZodString;
                projectId: z.ZodOptional<z.ZodString>;
                threadId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"project">;
                label: z.ZodString;
                projectId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"section">;
                label: z.ZodString;
                sectionId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                entryKind: z.ZodEnum<{
                    directory: "directory";
                    file: "file";
                }>;
                kind: z.ZodLiteral<"path">;
                label: z.ZodString;
                path: z.ZodString;
                source: z.ZodEnum<{
                    "thread-storage": "thread-storage";
                    workspace: "workspace";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                argumentHint: z.ZodNullable<z.ZodString>;
                kind: z.ZodLiteral<"command">;
                label: z.ZodString;
                name: z.ZodString;
                origin: z.ZodEnum<{
                    builtin: "builtin";
                    project: "project";
                    user: "user";
                }>;
                source: z.ZodEnum<{
                    command: "command";
                    skill: "skill";
                }>;
                trigger: z.ZodEnum<{
                    "/": "/";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                icon: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                itemId: z.ZodString;
                kind: z.ZodLiteral<"plugin">;
                label: z.ZodString;
                pluginId: z.ZodString;
            }, z.core.$strip>], "kind">>;
            start: z.ZodNumber;
        }, z.core.$strip>>>;
        text: z.ZodString;
        type: z.ZodLiteral<"text">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"image">;
        url: z.ZodString;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"localImage">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        mimeType: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        sizeBytes: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"localFile">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>], "type">>;
    inputGroups: z.ZodOptional<z.ZodArray<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mentions: z.ZodDefault<z.ZodArray<z.ZodObject<{
            end: z.ZodNumber;
            resource: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"thread">;
                label: z.ZodString;
                projectId: z.ZodOptional<z.ZodString>;
                threadId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"project">;
                label: z.ZodString;
                projectId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"section">;
                label: z.ZodString;
                sectionId: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                entryKind: z.ZodEnum<{
                    directory: "directory";
                    file: "file";
                }>;
                kind: z.ZodLiteral<"path">;
                label: z.ZodString;
                path: z.ZodString;
                source: z.ZodEnum<{
                    "thread-storage": "thread-storage";
                    workspace: "workspace";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                argumentHint: z.ZodNullable<z.ZodString>;
                kind: z.ZodLiteral<"command">;
                label: z.ZodString;
                name: z.ZodString;
                origin: z.ZodEnum<{
                    builtin: "builtin";
                    project: "project";
                    user: "user";
                }>;
                source: z.ZodEnum<{
                    command: "command";
                    skill: "skill";
                }>;
                trigger: z.ZodEnum<{
                    "/": "/";
                }>;
            }, z.core.$strip>, z.ZodObject<{
                icon: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                itemId: z.ZodString;
                kind: z.ZodLiteral<"plugin">;
                label: z.ZodString;
                pluginId: z.ZodString;
            }, z.core.$strip>], "kind">>;
            start: z.ZodNumber;
        }, z.core.$strip>>>;
        text: z.ZodString;
        type: z.ZodLiteral<"text">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"image">;
        url: z.ZodString;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"localImage">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        mimeType: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        sizeBytes: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"localFile">;
        visibility: z.ZodOptional<z.ZodEnum<{
            "agent-only": "agent-only";
        }>>;
    }, z.core.$strip>], "type">>>>;
    request: z.ZodObject<{
        method: z.ZodEnum<{
            "thread/start": "thread/start";
            "turn/start": "turn/start";
        }>;
        params: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strip>;
    requestId: z.ZodString;
    retryAttempt: z.ZodOptional<z.ZodNumber>;
    retryOfRequestId: z.ZodOptional<z.ZodString>;
    senderThreadId: z.ZodNullable<z.ZodString>;
    source: z.ZodEnum<{
        spawn: "spawn";
        tell: "tell";
    }>;
    systemMessageKind: z.ZodOptional<z.ZodEnum<{
        "child-completed": "child-completed";
        "child-failed": "child-failed";
        "child-interrupted": "child-interrupted";
        "child-needs-attention": "child-needs-attention";
        "child-outcome-batch": "child-outcome-batch";
        "ownership-assigned": "ownership-assigned";
        "ownership-removed": "ownership-removed";
        unlabeled: "unlabeled";
    }>>;
    systemMessageSubject: z.ZodOptional<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"thread">;
        threadId: z.ZodString;
        threadName: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        count: z.ZodNumber;
        kind: z.ZodLiteral<"thread-batch">;
    }, z.core.$strip>], "kind">>>;
    target: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"thread-start">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"new-turn">;
    }, z.core.$strip>, z.ZodObject<{
        expectedTurnId: z.ZodNullable<z.ZodString>;
        kind: z.ZodLiteral<"auto">;
    }, z.core.$strip>, z.ZodObject<{
        expectedTurnId: z.ZodNullable<z.ZodString>;
        kind: z.ZodLiteral<"steer">;
    }, z.core.$strip>], "kind">;
    threadId: z.ZodString;
    type: z.ZodLiteral<"client/turn/requested">;
}, z.core.$strip>, z.ZodObject<{
    message: z.ZodString;
    reason: z.ZodString;
    requestId: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"client/turn/rejected">;
}, z.core.$strip>, z.ZodObject<{
    direction: z.ZodLiteral<"outbound">;
    initiator: z.ZodEnum<{
        agent: "agent";
        system: "system";
        user: "user";
    }>;
    request: z.ZodObject<{
        method: z.ZodEnum<{
            "thread/start": "thread/start";
            "turn/start": "turn/start";
        }>;
        params: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strip>;
    source: z.ZodEnum<{
        spawn: "spawn";
        tell: "tell";
    }>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"client/turn/start">;
}, z.core.$strip>, z.ZodObject<{
    code: z.ZodOptional<z.ZodString>;
    detail: z.ZodOptional<z.ZodString>;
    message: z.ZodString;
    reconnectAttempt: z.ZodOptional<z.ZodNumber>;
    reconnectTotal: z.ZodOptional<z.ZodNumber>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"system/error">;
}, z.core.$strip>, z.ZodObject<{
    text: z.ZodString;
    threadId: z.ZodString;
    toolCallId: z.ZodOptional<z.ZodString>;
    turnId: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"system/manager/user_message">;
}, z.core.$strip>, z.ZodObject<{
    cause: z.ZodOptional<z.ZodLiteral<"host-connection-lost">>;
    reason: z.ZodEnum<{
        "host-daemon-restarted": "host-daemon-restarted";
        "manual-stop": "manual-stop";
        "provider-turn-idle": "provider-turn-idle";
    }>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"system/thread/interrupted">;
}, z.core.$strip>, z.ZodObject<{
    message: z.ZodString;
    metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
    operation: z.ZodString;
    operationId: z.ZodString;
    status: z.ZodString;
    threadId: z.ZodString;
    type: z.ZodLiteral<"system/operation">;
}, z.core.$strip>, z.ZodObject<{
    interaction: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        origin: z.ZodObject<{
            kind: z.ZodLiteral<"provider">;
            providerId: z.ZodString;
            providerRequestId: z.ZodString;
        }, z.core.$strip>;
        payload: z.ZodObject<{
            kind: z.ZodLiteral<"approval">;
            reason: z.ZodNullable<z.ZodString>;
            subject: z.ZodDiscriminatedUnion<[z.ZodObject<{
                actions: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    command: z.ZodString;
                    name: z.ZodString;
                    path: z.ZodString;
                    type: z.ZodLiteral<"read">;
                }, z.core.$strip>, z.ZodObject<{
                    command: z.ZodString;
                    path: z.ZodNullable<z.ZodString>;
                    type: z.ZodLiteral<"listFiles">;
                }, z.core.$strip>, z.ZodObject<{
                    command: z.ZodString;
                    path: z.ZodNullable<z.ZodString>;
                    query: z.ZodNullable<z.ZodString>;
                    type: z.ZodLiteral<"search">;
                }, z.core.$strip>, z.ZodObject<{
                    command: z.ZodString;
                    type: z.ZodLiteral<"unknown">;
                }, z.core.$strip>], "type">>;
                command: z.ZodString;
                cwd: z.ZodNullable<z.ZodString>;
                itemId: z.ZodString;
                kind: z.ZodLiteral<"command">;
                sessionGrant: z.ZodNullable<z.ZodObject<{
                    fileSystem: z.ZodNullable<z.ZodObject<{
                        read: z.ZodArray<z.ZodString>;
                        write: z.ZodArray<z.ZodString>;
                    }, z.core.$strip>>;
                    network: z.ZodNullable<z.ZodObject<{
                        enabled: z.ZodNullable<z.ZodBoolean>;
                    }, z.core.$strip>>;
                }, z.core.$strict>>;
            }, z.core.$strip>, z.ZodObject<{
                itemId: z.ZodString;
                kind: z.ZodLiteral<"file_change">;
                sessionGrant: z.ZodNullable<z.ZodObject<{
                    fileSystem: z.ZodNullable<z.ZodObject<{
                        read: z.ZodArray<z.ZodString>;
                        write: z.ZodArray<z.ZodString>;
                    }, z.core.$strip>>;
                    network: z.ZodNullable<z.ZodObject<{
                        enabled: z.ZodNullable<z.ZodBoolean>;
                    }, z.core.$strip>>;
                }, z.core.$strict>>;
                writeScope: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                itemId: z.ZodString;
                kind: z.ZodLiteral<"permission_grant">;
                permissions: z.ZodObject<{
                    fileSystem: z.ZodNullable<z.ZodObject<{
                        read: z.ZodArray<z.ZodString>;
                        write: z.ZodArray<z.ZodString>;
                    }, z.core.$strip>>;
                    network: z.ZodNullable<z.ZodObject<{
                        enabled: z.ZodNullable<z.ZodBoolean>;
                    }, z.core.$strip>>;
                }, z.core.$strict>;
                toolName: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                itemId: z.ZodString;
                kind: z.ZodLiteral<"plan">;
                plan: z.ZodString;
                planFilePath: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                itemId: z.ZodString;
                kind: z.ZodLiteral<"tool_use">;
                presentation: z.ZodObject<{
                    detail: z.ZodOptional<z.ZodString>;
                    icon: z.ZodObject<{
                        glyph: z.ZodString;
                    }, z.core.$strip>;
                    label: z.ZodObject<{
                        completed: z.ZodString;
                        pending: z.ZodString;
                    }, z.core.$strip>;
                    suppress: z.ZodOptional<z.ZodBoolean>;
                    tint: z.ZodOptional<z.ZodObject<{
                        dark: z.ZodString;
                        light: z.ZodString;
                    }, z.core.$strip>>;
                    title: z.ZodOptional<z.ZodString>;
                }, z.core.$strip>;
                tool: z.ZodString;
            }, z.core.$strip>], "kind">;
        }, z.core.$strip>;
        resolution: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            decision: z.ZodLiteral<"allow_once">;
            grantedPermissions: z.ZodNullable<z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
        }, z.core.$strip>, z.ZodObject<{
            decision: z.ZodLiteral<"allow_for_session">;
            grantedPermissions: z.ZodNullable<z.ZodObject<{
                fileSystem: z.ZodNullable<z.ZodObject<{
                    read: z.ZodArray<z.ZodString>;
                    write: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>;
                network: z.ZodNullable<z.ZodObject<{
                    enabled: z.ZodNullable<z.ZodBoolean>;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
        }, z.core.$strip>, z.ZodObject<{
            decision: z.ZodLiteral<"deny">;
        }, z.core.$strip>], "decision">>;
        status: z.ZodEnum<{
            interrupted: "interrupted";
            pending: "pending";
            resolved: "resolved";
            resolving: "resolving";
        }>;
        statusReason: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        origin: z.ZodObject<{
            kind: z.ZodLiteral<"provider">;
            providerId: z.ZodString;
            providerRequestId: z.ZodString;
        }, z.core.$strip>;
        payload: z.ZodObject<{
            kind: z.ZodLiteral<"user_question">;
            questions: z.ZodArray<z.ZodObject<{
                allowFreeText: z.ZodBoolean;
                id: z.ZodString;
                multiSelect: z.ZodBoolean;
                options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    description: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    value: z.ZodString;
                }, z.core.$strip>>>;
                prompt: z.ZodString;
                shortLabel: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>;
        resolution: z.ZodNullable<z.ZodObject<{
            answers: z.ZodRecord<z.ZodString, z.ZodObject<{
                freeText: z.ZodOptional<z.ZodString>;
                selected: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            kind: z.ZodLiteral<"user_answer">;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            interrupted: "interrupted";
            pending: "pending";
            resolved: "resolved";
            resolving: "resolving";
        }>;
        statusReason: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        origin: z.ZodObject<{
            kind: z.ZodLiteral<"plugin">;
            pluginId: z.ZodString;
            rendererId: z.ZodString;
        }, z.core.$strip>;
        payload: z.ZodObject<{
            kind: z.ZodLiteral<"plugin">;
            title: z.ZodString;
        }, z.core.$strip>;
        resolution: z.ZodNullable<z.ZodObject<{
            kind: z.ZodLiteral<"plugin_submitted">;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            interrupted: "interrupted";
            pending: "pending";
            resolved: "resolved";
            resolving: "resolving";
        }>;
        statusReason: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        id: z.ZodString;
        origin: z.ZodObject<{
            kind: z.ZodLiteral<"provider">;
            providerId: z.ZodString;
            providerRequestId: z.ZodString;
        }, z.core.$strip>;
        payload: z.ZodObject<{
            kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
            title: z.ZodString;
        }, z.core.$strip>;
        resolution: z.ZodNullable<z.ZodObject<{
            kind: z.ZodLiteral<"request_answer">;
        }, z.core.$strip>>;
        status: z.ZodEnum<{
            interrupted: "interrupted";
            pending: "pending";
            resolved: "resolved";
            resolving: "resolving";
        }>;
        statusReason: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>]>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"system/interaction/lifecycle">;
}, z.core.$strip>, z.ZodObject<{
    interactionId: z.ZodString;
    providerId: z.ZodString;
    providerRequestId: z.ZodString;
    resolution: z.ZodDefault<z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        decision: z.ZodLiteral<"allow_once">;
        grantedPermissions: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        decision: z.ZodLiteral<"allow_for_session">;
        grantedPermissions: z.ZodNullable<z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strip>, z.ZodObject<{
        decision: z.ZodLiteral<"deny">;
    }, z.core.$strip>], "decision">>>;
    status: z.ZodEnum<{
        interrupted: "interrupted";
        pending: "pending";
        resolved: "resolved";
        resolving: "resolving";
    }>;
    statusReason: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    subject: z.ZodObject<{
        itemId: z.ZodString;
        kind: z.ZodLiteral<"permission_grant">;
        permissions: z.ZodObject<{
            fileSystem: z.ZodNullable<z.ZodObject<{
                read: z.ZodArray<z.ZodString>;
                write: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
            network: z.ZodNullable<z.ZodObject<{
                enabled: z.ZodNullable<z.ZodBoolean>;
            }, z.core.$strip>>;
        }, z.core.$strict>;
        toolName: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"system/permissionGrant/lifecycle">;
}, z.core.$strip>, z.ZodObject<{
    interactionId: z.ZodString;
    payload: z.ZodObject<{
        kind: z.ZodLiteral<"user_question">;
        questions: z.ZodArray<z.ZodObject<{
            allowFreeText: z.ZodBoolean;
            id: z.ZodString;
            multiSelect: z.ZodBoolean;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                description: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                value: z.ZodString;
            }, z.core.$strip>>>;
            prompt: z.ZodString;
            shortLabel: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    providerId: z.ZodString;
    providerRequestId: z.ZodString;
    resolution: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        answers: z.ZodRecord<z.ZodString, z.ZodObject<{
            freeText: z.ZodOptional<z.ZodString>;
            selected: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
        kind: z.ZodLiteral<"user_answer">;
    }, z.core.$strip>>>;
    status: z.ZodEnum<{
        interrupted: "interrupted";
        pending: "pending";
        resolved: "resolved";
        resolving: "resolving";
    }>;
    statusReason: z.ZodDefault<z.ZodNullable<z.ZodString>>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"system/userQuestion/lifecycle">;
}, z.core.$strip>, z.ZodObject<{
    entries: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        startedAt: z.ZodOptional<z.ZodNumber>;
        status: z.ZodOptional<z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            started: "started";
        }>>;
        text: z.ZodString;
        type: z.ZodEnum<{
            output: "output";
            step: "step";
        }>;
    }, z.core.$strip>>;
    environmentId: z.ZodString;
    provisioningId: z.ZodString;
    status: z.ZodEnum<{
        active: "active";
        cancelled: "cancelled";
        completed: "completed";
        failed: "failed";
    }>;
    threadId: z.ZodString;
    type: z.ZodLiteral<"system/thread-provisioning">;
}, z.core.$strip>, z.ZodObject<{
    activeTurnId: z.ZodString;
    activeTurnStartedAt: z.ZodNumber;
    elapsedMs: z.ZodNumber;
    firedAt: z.ZodNumber;
    lastActivityEventAt: z.ZodNumber;
    lastActivityEventSequence: z.ZodNumber;
    lastActivityEventType: z.ZodString;
    providerId: z.ZodString;
    providerThreadId: z.ZodNullable<z.ZodString>;
    reason: z.ZodLiteral<"provider-turn-idle">;
    threadId: z.ZodString;
    thresholdMs: z.ZodNumber;
    type: z.ZodLiteral<"system/provider-turn-watchdog">;
}, z.core.$strip>], "type">, z.ZodObject<{
    scope: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"thread">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"turn">;
        turnId: z.ZodString;
    }, z.core.$strip>], "kind">;
}, z.core.$strip>>]>>;
type ThreadEvent = z.infer<typeof threadEventSchema>;

declare const promptInputSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mentions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        end: z.ZodNumber;
        resource: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"thread">;
            label: z.ZodString;
            projectId: z.ZodOptional<z.ZodString>;
            threadId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"project">;
            label: z.ZodString;
            projectId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"section">;
            label: z.ZodString;
            sectionId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            entryKind: z.ZodEnum<{
                directory: "directory";
                file: "file";
            }>;
            kind: z.ZodLiteral<"path">;
            label: z.ZodString;
            path: z.ZodString;
            source: z.ZodEnum<{
                "thread-storage": "thread-storage";
                workspace: "workspace";
            }>;
        }, z.core.$strip>, z.ZodObject<{
            argumentHint: z.ZodNullable<z.ZodString>;
            kind: z.ZodLiteral<"command">;
            label: z.ZodString;
            name: z.ZodString;
            origin: z.ZodEnum<{
                builtin: "builtin";
                project: "project";
                user: "user";
            }>;
            source: z.ZodEnum<{
                command: "command";
                skill: "skill";
            }>;
            trigger: z.ZodEnum<{
                "/": "/";
            }>;
        }, z.core.$strip>, z.ZodObject<{
            icon: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            itemId: z.ZodString;
            kind: z.ZodLiteral<"plugin">;
            label: z.ZodString;
            pluginId: z.ZodString;
        }, z.core.$strip>], "kind">>;
        start: z.ZodNumber;
    }, z.core.$strip>>>;
    text: z.ZodString;
    type: z.ZodLiteral<"text">;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"image">;
    url: z.ZodString;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    path: z.ZodString;
    type: z.ZodLiteral<"localImage">;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    mimeType: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
    sizeBytes: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"localFile">;
    visibility: z.ZodOptional<z.ZodEnum<{
        "agent-only": "agent-only";
    }>>;
}, z.core.$strip>], "type">;
type PromptInput = z.infer<typeof promptInputSchema>;

declare const bridgeGrammarVersionsSchema: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
type BridgeGrammarVersions = z.infer<typeof bridgeGrammarVersionsSchema>;

declare const threadDeltaSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    clientRequestId: z.ZodString;
    kind: z.ZodLiteral<"input.accepted">;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"input.provider">;
    parentRef: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"turn.open">;
    parentRef: z.ZodOptional<z.ZodString>;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    claimIfIdle: z.ZodOptional<z.ZodBoolean>;
    error: z.ZodOptional<z.ZodObject<{
        message: z.ZodString;
    }, z.core.$strip>>;
    kind: z.ZodLiteral<"turn.boundary">;
    providerCheckpointId: z.ZodOptional<z.ZodString>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
    }>;
}, z.core.$strip>, z.ZodObject<{
    attach: z.ZodOptional<z.ZodEnum<{
        currentOrLast: "currentOrLast";
        open: "open";
    }>>;
    item: z.ZodDiscriminatedUnion<[z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodString>;
        command: z.ZodString;
        cwd: z.ZodString;
        durationMs: z.ZodOptional<z.ZodNumber>;
        exitCode: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"command">;
    }, z.core.$strip>, z.ZodObject<{
        changes: z.ZodArray<z.ZodObject<{
            diff: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                add: "add";
                delete: "delete";
                update: "update";
            }>;
            movePath: z.ZodOptional<z.ZodString>;
            newText: z.ZodOptional<z.ZodString>;
            oldText: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"fileChange">;
    }, z.core.$strip>, z.ZodObject<{
        args: z.ZodOptional<z.ZodUnknown>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodString>;
        result: z.ZodOptional<z.ZodUnknown>;
        server: z.ZodOptional<z.ZodString>;
        tool: z.ZodString;
        type: z.ZodLiteral<"tool">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compaction">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"agentMessage">;
    }, z.core.$strip>, z.ZodObject<{
        content: z.ZodArray<z.ZodString>;
        summary: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"reasoning">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"plan">;
    }, z.core.$strip>, z.ZodObject<{
        queries: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"webSearch">;
    }, z.core.$strip>, z.ZodObject<{
        pattern: z.ZodNullable<z.ZodString>;
        prompt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        type: z.ZodLiteral<"webFetch">;
        url: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"imageView">;
    }, z.core.$strip>, z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        type: z.ZodLiteral<"fileRead">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        mode: z.ZodEnum<{
            content: "content";
            list: "list";
            path: "path";
        }>;
        path: z.ZodOptional<z.ZodString>;
        query: z.ZodString;
        type: z.ZodLiteral<"search">;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        label: z.ZodString;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>, z.ZodObject<{
        explanation: z.ZodOptional<z.ZodString>;
        steps: z.ZodArray<z.ZodObject<{
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                completed: "completed";
                failed: "failed";
                pending: "pending";
            }>>;
            step: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"planSteps">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        type: z.ZodLiteral<"extension">;
    }, z.core.$strip>], "type">;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.open">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    aggregatedOutput: z.ZodOptional<z.ZodString>;
    approvalStatus: z.ZodOptional<z.ZodLiteral<"denied">>;
    exitCode: z.ZodOptional<z.ZodNumber>;
    item: z.ZodDiscriminatedUnion<[z.ZodObject<{
        aggregatedOutput: z.ZodOptional<z.ZodString>;
        command: z.ZodString;
        cwd: z.ZodString;
        durationMs: z.ZodOptional<z.ZodNumber>;
        exitCode: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"command">;
    }, z.core.$strip>, z.ZodObject<{
        changes: z.ZodArray<z.ZodObject<{
            diff: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                add: "add";
                delete: "delete";
                update: "update";
            }>;
            movePath: z.ZodOptional<z.ZodString>;
            newText: z.ZodOptional<z.ZodString>;
            oldText: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"fileChange">;
    }, z.core.$strip>, z.ZodObject<{
        args: z.ZodOptional<z.ZodUnknown>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        error: z.ZodOptional<z.ZodString>;
        result: z.ZodOptional<z.ZodUnknown>;
        server: z.ZodOptional<z.ZodString>;
        tool: z.ZodString;
        type: z.ZodLiteral<"tool">;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compaction">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"agentMessage">;
    }, z.core.$strip>, z.ZodObject<{
        content: z.ZodArray<z.ZodString>;
        summary: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"reasoning">;
    }, z.core.$strip>, z.ZodObject<{
        text: z.ZodString;
        type: z.ZodLiteral<"plan">;
    }, z.core.$strip>, z.ZodObject<{
        queries: z.ZodArray<z.ZodString>;
        type: z.ZodLiteral<"webSearch">;
    }, z.core.$strip>, z.ZodObject<{
        pattern: z.ZodNullable<z.ZodString>;
        prompt: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        type: z.ZodLiteral<"webFetch">;
        url: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        path: z.ZodString;
        type: z.ZodLiteral<"imageView">;
    }, z.core.$strip>, z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
        type: z.ZodLiteral<"fileRead">;
    }, z.core.$strip>, z.ZodObject<{
        cmd: z.ZodOptional<z.ZodString>;
        mode: z.ZodEnum<{
            content: "content";
            list: "list";
            path: "path";
        }>;
        path: z.ZodOptional<z.ZodString>;
        query: z.ZodString;
        type: z.ZodLiteral<"search">;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        label: z.ZodString;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>, z.ZodObject<{
        explanation: z.ZodOptional<z.ZodString>;
        steps: z.ZodArray<z.ZodObject<{
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                completed: "completed";
                failed: "failed";
                pending: "pending";
            }>>;
            step: z.ZodString;
        }, z.core.$strip>>;
        type: z.ZodLiteral<"planSteps">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        type: z.ZodLiteral<"extension">;
    }, z.core.$strip>], "type">;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.close">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    presentation: z.ZodOptional<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        icon: z.ZodObject<{
            glyph: z.ZodString;
        }, z.core.$strip>;
        label: z.ZodObject<{
            completed: z.ZodString;
            pending: z.ZodString;
        }, z.core.$strip>;
        suppress: z.ZodOptional<z.ZodBoolean>;
        tint: z.ZodOptional<z.ZodObject<{
            dark: z.ZodString;
            light: z.ZodString;
        }, z.core.$strip>>;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    resultText: z.ZodOptional<z.ZodString>;
    status: z.ZodEnum<{
        completed: "completed";
        failed: "failed";
        interrupted: "interrupted";
        pending: "pending";
    }>;
}, z.core.$strip>, z.ZodObject<{
    flush: z.ZodOptional<z.ZodBoolean>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.progress">;
    message: z.ZodOptional<z.ZodString>;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    snapshot: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        description: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        familyId: z.ZodString;
        outputFile: z.ZodOptional<z.ZodString>;
        skipTranscript: z.ZodBoolean;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
            pending: "pending";
        }>;
        summary: z.ZodOptional<z.ZodString>;
        taskStatus: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            killed: "killed";
            paused: "paused";
            pending: "pending";
            running: "running";
            stopped: "stopped";
        }>;
        taskType: z.ZodString;
        type: z.ZodLiteral<"backgroundTask">;
        usage: z.ZodOptional<z.ZodObject<{
            durationMs: z.ZodNumber;
            toolUses: z.ZodNumber;
            totalTokens: z.ZodNumber;
        }, z.core.$strip>>;
        workflow: z.ZodOptional<z.ZodObject<{
            agents: z.ZodArray<z.ZodObject<{
                agentType: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
                cached: z.ZodBoolean;
                durationMs: z.ZodOptional<z.ZodNumber>;
                error: z.ZodOptional<z.ZodString>;
                index: z.ZodNumber;
                isolation: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                lastProgressAt: z.ZodNumber;
                lastToolName: z.ZodOptional<z.ZodString>;
                lastToolSummary: z.ZodOptional<z.ZodString>;
                model: z.ZodString;
                phaseIndex: z.ZodOptional<z.ZodNumber>;
                phaseTitle: z.ZodOptional<z.ZodString>;
                promptPreview: z.ZodOptional<z.ZodString>;
                queuedAt: z.ZodOptional<z.ZodNumber>;
                resultPreview: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodOptional<z.ZodNumber>;
                state: z.ZodEnum<{
                    done: "done";
                    failed: "failed";
                    queued: "queued";
                    running: "running";
                    skipped: "skipped";
                }>;
                tokens: z.ZodOptional<z.ZodNumber>;
                toolCalls: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            phases: z.ZodArray<z.ZodObject<{
                index: z.ZodNumber;
                kind: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        workflowName: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        background: z.ZodBoolean;
        childRef: z.ZodString;
        label: z.ZodString;
        summary: z.ZodOptional<z.ZodString>;
        type: z.ZodLiteral<"delegation">;
    }, z.core.$strip>], "type">>;
}, z.core.$strip>, z.ZodObject<{
    channel: z.ZodEnum<{
        agentMessage: "agentMessage";
        plan: "plan";
        reasoningSummary: "reasoningSummary";
        reasoningText: "reasoningText";
    }>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.textDelta">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    channel: z.ZodEnum<{
        agentMessage: "agentMessage";
        plan: "plan";
        reasoningSummary: "reasoningSummary";
        reasoningText: "reasoningText";
    }>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.textClose">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    text: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    channel: z.ZodEnum<{
        command: "command";
        fileChange: "fileChange";
    }>;
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"item.outputDelta">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    key: z.ZodObject<{
        channel: z.ZodOptional<z.ZodString>;
        parentRef: z.ZodOptional<z.ZodString>;
        providerItemId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    kind: z.ZodLiteral<"command.outputSnapshot">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"usage">;
    last: z.ZodObject<{
        cachedInputTokens: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        reasoningOutputTokens: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>;
    modelContextWindow: z.ZodNullable<z.ZodNumber>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    total: z.ZodObject<{
        cachedInputTokens: z.ZodNumber;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        reasoningOutputTokens: z.ZodNumber;
        totalTokens: z.ZodNumber;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    attach: z.ZodEnum<{
        currentOrLast: "currentOrLast";
        open: "open";
    }>;
    estimated: z.ZodBoolean;
    kind: z.ZodLiteral<"contextWindow">;
    providerTurnId: z.ZodOptional<z.ZodString>;
    size: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    used: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"context.compacted">;
    noTurnFallback: z.ZodOptional<z.ZodObject<{
        raw: z.ZodObject<{
            id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            jsonrpc: z.ZodLiteral<"2.0">;
            method: z.ZodString;
            params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
        }, z.core.$strip>;
        rawType: z.ZodString;
    }, z.core.$strip>>;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"context.cleared">;
}, z.core.$strip>, z.ZodObject<{
    diff: z.ZodString;
    kind: z.ZodLiteral<"turn.diff">;
    providerTurnId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"thread.started">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"thread.identity">;
    providerThreadId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"thread.name">;
    name: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    extensionKind: z.ZodString & z.ZodType<`${string}/${string}`, string, z.core.$ZodTypeInternals<`${string}/${string}`, string>>;
    kind: z.ZodLiteral<"extension.state">;
    payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"provider.rateLimits">;
    rateLimits: z.ZodObject<{
        kind: z.ZodEnum<{
            "spend-control": "spend-control";
            "subscription-window": "subscription-window";
            credits: "credits";
            unknown: "unknown";
        }>;
        overageReason: z.ZodNullable<z.ZodString>;
        overageStatus: z.ZodNullable<z.ZodEnum<{
            allowed: "allowed";
            rejected: "rejected";
            unavailable: "unavailable";
            warning: "warning";
        }>>;
        providerId: z.ZodString;
        reachedReason: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<{
            allowed: "allowed";
            blocked: "blocked";
            unknown: "unknown";
            warning: "warning";
        }>;
        windows: z.ZodArray<z.ZodObject<{
            label: z.ZodNullable<z.ZodString>;
            providerKey: z.ZodNullable<z.ZodString>;
            resetsAtMs: z.ZodNullable<z.ZodNumber>;
            status: z.ZodEnum<{
                allowed: "allowed";
                blocked: "blocked";
                unknown: "unknown";
                warning: "warning";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    category: z.ZodOptional<z.ZodEnum<{
        "active-turn-not-steerable": "active-turn-not-steerable";
        "bad-request": "bad-request";
        "budget-exceeded": "budget-exceeded";
        "connection-failed": "connection-failed";
        "context-window-exceeded": "context-window-exceeded";
        "max-output-tokens": "max-output-tokens";
        "max-turns": "max-turns";
        "rate-limit": "rate-limit";
        "stream-disconnected": "stream-disconnected";
        "structured-output-retries": "structured-output-retries";
        "thread-rollback-failed": "thread-rollback-failed";
        "too-many-failed-attempts": "too-many-failed-attempts";
        billing: "billing";
        internal: "internal";
        overloaded: "overloaded";
        policy: "policy";
        sandbox: "sandbox";
        unauthorized: "unauthorized";
        unknown: "unknown";
    }>>;
    detail: z.ZodOptional<z.ZodString>;
    errorInfo: z.ZodOptional<z.ZodObject<{
        category: z.ZodEnum<{
            "active-turn-not-steerable": "active-turn-not-steerable";
            "bad-request": "bad-request";
            "budget-exceeded": "budget-exceeded";
            "connection-failed": "connection-failed";
            "context-window-exceeded": "context-window-exceeded";
            "max-output-tokens": "max-output-tokens";
            "max-turns": "max-turns";
            "rate-limit": "rate-limit";
            "stream-disconnected": "stream-disconnected";
            "structured-output-retries": "structured-output-retries";
            "thread-rollback-failed": "thread-rollback-failed";
            "too-many-failed-attempts": "too-many-failed-attempts";
            billing: "billing";
            internal: "internal";
            overloaded: "overloaded";
            policy: "policy";
            sandbox: "sandbox";
            unauthorized: "unauthorized";
            unknown: "unknown";
        }>;
        httpStatusCode: z.ZodNullable<z.ZodNumber>;
        providerCode: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    kind: z.ZodLiteral<"provider.error">;
    message: z.ZodString;
    providerTurnId: z.ZodOptional<z.ZodString>;
    settlesTurn: z.ZodOptional<z.ZodBoolean>;
    threadScoped: z.ZodOptional<z.ZodBoolean>;
    willRetry: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    fallbackModel: z.ZodString;
    kind: z.ZodLiteral<"provider.modelFallback">;
    message: z.ZodString;
    originalModel: z.ZodString;
    reason: z.ZodEnum<{
        provider: "provider";
        refusal: "refusal";
    }>;
}, z.core.$strip>, z.ZodObject<{
    category: z.ZodOptional<z.ZodEnum<{
        "compaction-skipped": "compaction-skipped";
        config: "config";
        deprecation: "deprecation";
        general: "general";
    }>>;
    details: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"provider.warning">;
    summary: z.ZodOptional<z.ZodString>;
    vouchedTurn: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"unhandled">;
    onlyIfNoTurn: z.ZodOptional<z.ZodBoolean>;
    parentRef: z.ZodOptional<z.ZodString>;
    providerTurnId: z.ZodOptional<z.ZodString>;
    raw: z.ZodObject<{
        id: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        jsonrpc: z.ZodLiteral<"2.0">;
        method: z.ZodString;
        params: z.ZodOptional<z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>;
    }, z.core.$strip>;
    rawType: z.ZodString;
    vouchedTurn: z.ZodBoolean;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"session.ended">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"session.reset">;
}, z.core.$strip>], "kind">;
type ThreadDelta = z.infer<typeof threadDeltaSchema>;

declare const ASSEMBLER_GRAMMAR_VERSIONS: BridgeGrammarVersions;
interface DiffCumulativeTextArgs {
    nextText: string;
    previousText?: string;
}
interface DiffCumulativeTextResult {
    delta: string;
    nextText: string;
    reset: boolean;
}
interface CreateDeltaAssemblerOptions {
    providerId: string;
    entropyPrefix?: string;
    progressThrottleMs?: number;
    textDeltaFlushMs?: number;
    now?: () => number;
}
interface AssembleDeltasArgs {
    threadId: string;
    deltas: readonly ThreadDelta[];
}
interface DeltaAssembler {
    assemble(args: AssembleDeltasArgs): ThreadEvent[];
    getBbItemId(threadId: string, providerItemId: string): string | undefined;
    getProviderItemId(threadId: string, bbItemId: string): string | undefined;
    getBbTurnId(threadId: string, providerTurnId: string): string | undefined;
    getProviderTurnId(threadId: string, bbTurnId: string): string | undefined;
    getOpenTurnId(threadId: string): string | undefined;
}
declare function createDeltaAssembler(options: CreateDeltaAssemblerOptions): DeltaAssembler;

interface CapturedBridgeNotification {
    method?: string;
    params?: unknown;
}
interface BridgeDeltaEventCollector {
    assembler: DeltaAssembler;
    assembleMessage(message: CapturedBridgeNotification): ThreadEvent[];
}
declare function createBridgeDeltaEventCollector(providerId?: string): BridgeDeltaEventCollector;
declare function assembleCapturedThreadEvents(messages: readonly CapturedBridgeNotification[], providerId?: string): ThreadEvent[];
declare function toConformanceMessages(): never;

interface BridgeConformanceTransport {
    send(line: string): void;
    takeMessages(): unknown[];
    close?(): Promise<void> | void;
}
declare const CONFORMANCE_ASSEMBLED_EVENT_METHOD = "conformance/assembledEvent";
type ConformanceStatus = "fail" | "pass" | "skipped";
interface ConformanceCheckResult {
    id: string;
    title: string;
    status: ConformanceStatus;
    detail: string;
}
interface ConformanceReport {
    results: ConformanceCheckResult[];
    passed: boolean;
}

interface ConformanceSessionFixture {
    cwd: string;
    promptInput: PromptInput[];
    zeroWorkPromptInput?: PromptInput[];
    interruptiblePromptInput?: PromptInput[];
    options?: Record<string, unknown>;
    icons?: {
        pluginId: string;
        names: readonly string[];
    };
}

declare const RECORDED_CONFORMANCE_CELLS: readonly ["turn-tools", "steer", "stop-interrupt", "approval-allow", "approval-deny", "user-question", "resume", "fork"];
type RecordedConformanceCell = (typeof RECORDED_CONFORMANCE_CELLS)[number];
interface RecordedCellReplay {
    provider: string;
    cell: string;
    events: readonly ThreadEvent[];
    recordedEvents: readonly ThreadEvent[];
    stalls: readonly string[];
}
declare function checkRecordedCellReplay(replay: RecordedCellReplay): ConformanceCheckResult[];

interface RunBridgeConformanceOptions {
    transport: BridgeConformanceTransport;
    session: ConformanceSessionFixture;
    providerId: string;
    timeoutMs?: number;
}
declare function runBridgeConformance(options: RunBridgeConformanceOptions): Promise<ConformanceReport>;
declare function formatConformanceReport(report: ConformanceReport): string;

type BridgeJsonRpcId = string | number;
type BridgeJsonRpcLineHandler = (line: string) => void;
interface BridgeJsonRpcObject {
    [key: string]: JsonValue;
}
interface BridgeJsonRpcOutputMessage {
    jsonrpc: "2.0";
    id?: BridgeJsonRpcId;
    method?: string;
    params?: JsonValue;
    result?: JsonValue;
    error?: {
        code: number;
        message: string;
        data?: JsonValue;
    };
}
interface CapturedBridgeJsonRpcOutput {
    messages: BridgeJsonRpcOutputMessage[];
    takeMessages(): BridgeJsonRpcOutputMessage[];
    restore(): void;
}
interface BridgeJsonRpcTestHarness {
    messages: BridgeJsonRpcOutputMessage[];
    takeMessages(): BridgeJsonRpcOutputMessage[];
    flushWork(): Promise<void>;
    hasResponse(id: BridgeJsonRpcId): boolean;
    restore(): void;
    sendRequest(id: BridgeJsonRpcId, method: string, params: BridgeJsonRpcObject): void;
    waitForResponse(id: BridgeJsonRpcId): Promise<BridgeJsonRpcOutputMessage>;
}
declare function captureBridgeJsonRpcOutput(): CapturedBridgeJsonRpcOutput;
declare function createBridgeJsonRpcTestHarness(handleLine: BridgeJsonRpcLineHandler): BridgeJsonRpcTestHarness;

interface NormalizeCalibrationEventsOptions {
    internedIdFields?: readonly string[];
}
declare function normalizeCalibrationEvents(events: readonly ThreadEvent[], options?: NormalizeCalibrationEventsOptions): unknown[];
declare function describeCalibrationEvents(events: readonly unknown[]): string[];

declare const BRIDGE_RECORDING_DIRECTIONS: readonly ["runtime→bridge", "bridge→runtime", "provider→bridge", "bridge→provider"];
type BridgeRecordingDirection = (typeof BRIDGE_RECORDING_DIRECTIONS)[number];
interface BridgeRecordingEntry {
    ts: number;
    run: number;
    seq: number;
    dir: BridgeRecordingDirection;
    line: string;
}

interface BridgeRecordingManifest {
    provider: string;
    cell: string;
    threadId: string | null;
    scope: "process" | "thread";
    cliVersion: string;
    recordedAt: string;
    description: string;
    note: string;
    bridgeRuns: number;
    lines: Partial<Record<BridgeRecordingDirection, number>>;
}
interface BridgeRecording {
    dir: string;
    manifest: BridgeRecordingManifest | null;
    entries: BridgeRecordingEntry[];
}
declare const CURRENT_BRIDGE_LANE_FILE = "bridge\u2192runtime.current.ndjson";
declare function withCurrentBridgeLane(recording: BridgeRecording): BridgeRecording;
declare function readBridgeRecording(dir: string): BridgeRecording;
interface RecordedCell {
    provider: string;
    cell: string;
    dir: string;
}
declare function listRecordedCells(root: string): RecordedCell[];

interface ParityAssembler {
    assembleMessage(message: {
        method?: string;
        params?: unknown;
    }): ThreadEvent[];
}
type CreateParityAssembler = (providerId: string) => ParityAssembler;
type ParityRowProjector = (args: {
    events: readonly ThreadEvent[];
    providerId: string;
}) => unknown[];
interface ProviderBridgeLaunch {
    command: string;
    args: string[];
    cwd: string;
    env: Record<string, string>;
}
interface ResolveProviderBridgeLaunchOptions {
    modulePath: string;
    pluginId: string;
    cwd?: string;
    dataDir?: string;
    bootstrapPath?: string;
    nodeArgs?: string[];
}
declare function resolveProviderBridgeLaunch(options: ResolveProviderBridgeLaunchOptions): ProviderBridgeLaunch;
type ReplayDialect = "claude-cli" | "json-rpc" | "pi-rpc";
interface ReplayProviderProfile {
    dialect: ReplayDialect;
    env(args: {
        replayCommand: string[];
        wrapperPath: string;
        stateDir: string;
    }): Record<string, string>;
    rewriteRuntimeLine?(line: string, args: {
        replayCommand: string[];
    }): string;
    prepareState?(args: {
        recording: BridgeRecording;
        stateDir: string;
        workspaceDir: string;
    }): void;
}
declare const DEFAULT_REPLAY_PROFILE: ReplayProviderProfile;
interface ReplayRecordingOptions {
    recordingDir: string;
    providerId: string;
    bridge: ProviderBridgeLaunch;
    profile?: ReplayProviderProfile;
    createAssembler: CreateParityAssembler;
    createPlanAssembler?: CreateParityAssembler;
    planFromCurrentLane?: boolean;
    timeoutMs?: number;
    orderTimeoutMs?: number;
    settleMs?: number;
    drainMs?: number;
    onStderr?: (text: string) => void;
}
interface ParityGrammarViolation {
    rule: string;
    reason: string;
    eventType: string;
}
interface ParityRun {
    providerId: string;
    recordingDir: string;
    lines: string[];
    lineTimes: number[];
    lineAfter: Array<{
        run: number;
        seq: number;
        ts: number;
    } | null>;
    events: ThreadEvent[];
    grammarViolations: ParityGrammarViolation[];
    stalls: string[];
    stderr: string;
    exitCode: number | null;
}
declare const PARITY_INITIALIZE_ID = "parity-initialize";
declare function replayRecording(options: ReplayRecordingOptions): Promise<ParityRun>;
declare function assembleRecordedEvents(recording: BridgeRecording, createAssembler: CreateParityAssembler, providerId: string): {
    events: ThreadEvent[];
    grammarViolations: ParityGrammarViolation[];
    invalidDeltas: string[];
};
interface ParityAllowlistEntry {
    provider: string | "*";
    cell: string | "*";
    layer: "events" | "rows";
    path: string;
    pr: string;
    reason: string;
}
interface ParityLayerDiff {
    onlyInOld: unknown[];
    onlyInNew: unknown[];
}
interface ParityComparison {
    provider: string;
    cell: string;
    events: ParityLayerDiff;
    rows: ParityLayerDiff;
    grammar: ParityLayerDiff;
    staleAllowlist: ParityAllowlistEntry[];
    passed: boolean;
}
interface ParityInputs {
    events: readonly ThreadEvent[];
    rows: readonly unknown[];
    grammarViolations?: readonly ParityGrammarViolation[];
}
declare function compareParity(oldRun: ParityInputs, newRun: ParityInputs, allowlist: readonly ParityAllowlistEntry[], scope: {
    provider: string;
    cell: string;
}): ParityComparison;
interface ReplayRecordedCellsOptions {
    recordingsRoot: string;
    servesProvider: (providerId: string) => boolean;
    cells?: readonly string[];
    bridge: (cell: RecordedCell) => {
        launch: ProviderBridgeLaunch;
        profile?: ReplayProviderProfile;
    };
    createAssembler: CreateParityAssembler;
    timeoutMs?: number;
    onStderr?: (text: string) => void;
}

type RerecordCurrentBridgeLaneOptions = Omit<ReplayRecordingOptions, "planFromCurrentLane">;
interface RerecordCurrentBridgeLaneResult {
    file: string | null;
    lines: number;
    events: number;
    stalls: string[];
}
declare function rerecordCurrentBridgeLane(options: RerecordCurrentBridgeLaneOptions): Promise<RerecordCurrentBridgeLaneResult>;

export { ASSEMBLER_GRAMMAR_VERSIONS, CONFORMANCE_ASSEMBLED_EVENT_METHOD, CURRENT_BRIDGE_LANE_FILE, DEFAULT_REPLAY_PROFILE, PARITY_INITIALIZE_ID, RECORDED_CONFORMANCE_CELLS, assembleCapturedThreadEvents as experimental_assembleCapturedThreadEvents, assembleRecordedEvents as experimental_assembleRecordedEvents, captureBridgeJsonRpcOutput as experimental_captureBridgeJsonRpcOutput, checkRecordedCellReplay as experimental_checkRecordedCellReplay, compareParity as experimental_compareParity, createBridgeDeltaEventCollector as experimental_createBridgeDeltaEventCollector, createBridgeJsonRpcTestHarness as experimental_createBridgeJsonRpcTestHarness, createDeltaAssembler as experimental_createDeltaAssembler, describeCalibrationEvents as experimental_describeCalibrationEvents, formatConformanceReport as experimental_formatConformanceReport, listRecordedCells as experimental_listRecordedCells, normalizeCalibrationEvents as experimental_normalizeCalibrationEvents, readBridgeRecording as experimental_readBridgeRecording, replayRecording as experimental_replayRecording, rerecordCurrentBridgeLane as experimental_rerecordCurrentBridgeLane, resolveProviderBridgeLaunch as experimental_resolveProviderBridgeLaunch, runBridgeConformance as experimental_runBridgeConformance, toConformanceMessages as experimental_toConformanceMessages, withCurrentBridgeLane as experimental_withCurrentBridgeLane };
export type { AssembleDeltasArgs, BridgeConformanceTransport, BridgeDeltaEventCollector, BridgeJsonRpcId, BridgeJsonRpcLineHandler, BridgeJsonRpcObject, BridgeJsonRpcOutputMessage, BridgeJsonRpcTestHarness, BridgeRecording, BridgeRecordingDirection, BridgeRecordingEntry, BridgeRecordingManifest, CapturedBridgeJsonRpcOutput, CapturedBridgeNotification, ConformanceCheckResult, ConformanceReport, ConformanceSessionFixture, CreateDeltaAssemblerOptions, CreateParityAssembler, DeltaAssembler, DiffCumulativeTextArgs, DiffCumulativeTextResult, NormalizeCalibrationEventsOptions, ParityAllowlistEntry, ParityAssembler, ParityComparison, ParityGrammarViolation, ParityInputs, ParityLayerDiff, ParityRowProjector, ParityRun, ProviderBridgeLaunch, RecordedCell, RecordedCellReplay, RecordedConformanceCell, ReplayDialect, ReplayProviderProfile, ReplayRecordedCellsOptions, ReplayRecordingOptions, RerecordCurrentBridgeLaneOptions, RerecordCurrentBridgeLaneResult, ResolveProviderBridgeLaunchOptions, RunBridgeConformanceOptions, ThreadEvent, ThreadEventBackgroundTaskItem, ThreadEventDelegationItem, ThreadEventExtensionItem, ThreadEventFileReadItem, ThreadEventItem, ThreadEventItemPresentation, ThreadEventItemPresentationIcon, ThreadEventItemPresentationLabel, ThreadEventItemPresentationTint, ThreadEventPlanStepsItem, ThreadEventSearchItem, ThreadEventWebFetchItem, ThreadEventWebSearchItem };
